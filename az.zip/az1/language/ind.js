exports.wait = () => {
	return`*⏰ AGUARDE UM MOMENTO!*📌`
}

exports.succes = () => {
	return`*Sucesso 🖤*`
}

exports.lvlon = () => {
	return`*Os níveis está ativado*`
}

exports.lvloff = () => {
	return`*Os níveis está desativado 😔*`
}

exports.adultoff = () => {
  return `O conteúdo adulto não está ativado`
}

exports.adulton = () => {
  return `Conteúdo adulto ativado!`
}

exports.adultt = () => {
  return `Ja está ativado!!`
}

exports.lvlnul = () => {
	return`_Você ainda não tem um nível!_`
}

exports.lvlnoon = () => {
	return`*Peça a um adm para ativar os níveis neste grupo!*`
}

exports.noregis = () => {
	return`*「 NÃO REGISTRADO 」*

*🤝 Percebemos que você ainda não está registrado(a) em nosso banco de dados... para está se registrando use !rg nome|idade - obs: use isso no privado do bot!* 

•Exemplo: !rg aztro|18`
}

exports.rediregis = () => {
	return`*Você já está registrado em nosso banco de dados 🏦🎲🤝*`
}

exports.stikga = () => {
	return`*Falha, tente novamente mais tarde!*`
}

exports.linkga = () => {
	return`*Link inválido*`
}

exports.groupo = () => {
	return`*Comando só pode ser utilizado em grupos!*`
}

exports.ownerb = () => {
	return`Quem é você? 😕`
}

exports.ownerg = () => {
	return`*🚫*`
} 
exports.vip = () => { 
  return `_Você não possui uma conta vip! 😢_` 
}

exports.admin = () => {
	return`_sai fora membro comum 🤣🤣🤣_`
}
exports.nivel = () => { 
  return`*Para fazer uso deste comando é nescessário ter o nível 3 👳🏿‍♂️*`
} 
exports.badmin = () => {
	return`*Bot não possui adm 😭*`
}

exports.nsfwoff = () => {
	return`*`
}

exports.bug = () => {
	return`*`
}

exports.wrongf = () => {
	return`*Formato incorreto / texto em branco 🤨*`
}

exports.clears = () => {
	return`Todas as conversas foram apagadas :b`
}

exports.pc = () => {
	return`*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender) => {
	return`Panas🤝, cadastro bem sucedido 🔒`
}

exports.cmdnf = (prefix, command) => {
	return`Comando *${prefix}${command}* não encontrado, use esse *${prefix}menu*`
}

exports.owneresce = (pushname) => {
	return`*`
}

exports.menu = (pushname, prefix, getLevelingLevel, getLevelingXp, sender, reqXp, _registered, uangku) => { 
	return ` ❍ Prefix: 「 ${prefix} 」
 ❍ Status: Online 
  
  !menu 
  !criadorbot
  
  !info 
  !ping
  
  !sticker 
  !stickergif
  !imagem 
  !audio {código do idioma} {fala}
  
  !caracoroa 
  !gay 
  !resp {sua pergunta}
  !nivel
  
  !cadr {texto}
  !pokemon
  !beijar
  
  !play {nome da música}
  !ytmp4 {url yt}
  !ytmp3 {url yt}
  
  !ssweb {url} 
  !encurta {url}
  !tiktokstalk {id/nome do usuário}
  
  !promover @tagmembro
  !demitir @tagadmin 
  
  !ban @tagmembro 
  !add {quem você quer add?} 
  !convite 
  
  !setname {nome novo do gruoo}
  !setdesc {descrição nova do grupo} 
  !setmarc {marcação nova}
  
  !atnivel {on/off} 
  !welcome {1/0} 
  !antilinkgrupo {1/0}
  !gp {open/close}
  !pesquisa 

  !here 
  !marcar
   
  !deleter / !del
  !clearall
  !clone @tagmembro
`}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel, role, limitCounts) => {
	return`
╭╼≽ *「 🔥LEVEL UP🔥 」*
│≽ *Nome* : ${pushname}
│≽ *Número* : wa.me/${sender.split("@")[0]}
│≽ *XP* : ${getLevelingXp(sender)}
│≽ *Limite* : ${limitCounts}
│≽ *Patente*: ${role}
╰╼≽ *Level* : ${getLevel} ⊱ ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*desculpa ${pushname} seu limite acabou\nNOTA: limite pode ser obtido por ${prefix}buylimit ou subindo de nível*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 LIMITE DA CONTA 」*
Seu limite : ${limitCounts}`
}

exports.satukos = () => {
	return`ERROR`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`*╭╼≽ 「 PONTOS」─╮*\n│≽ *Nome* : ${pushname}\n│≽ *Número* : ${sender.split("@")[0]}\n│≽ *Pontos* : ${uangkau}\n╰─────────`
}
